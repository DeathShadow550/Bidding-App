import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Removes the debug banner
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Bidding Page'),
        ),
        body: const MaximumBid(),
      ),
    );
  }
}

class MaximumBid extends StatefulWidget {
  const MaximumBid({Key? key}) : super(key: key);

  @override
  _MaximumBidState createState() => _MaximumBidState();
}

class _MaximumBidState extends State<MaximumBid> {
  // Initial bid amount
  double _currentBid = 100.0;

  // Function to increase the bid by $50
  void _increaseBid() {
    setState(() {
      _currentBid += 50.0;
    });
  }

  // Function to decrease the bid by $50, ensuring it doesn't go below zero
  void _decreaseBid() {
    setState(() {
      if (_currentBid > 50.0) {
        _currentBid -= 50.0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Displaying the current maximum bid
          Text(
            'Your Current Maximum Bid:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            '\$${_currentBid.toStringAsFixed(2)}',
            style: TextStyle(fontSize: 32, color: Colors.green),
          ),
          const SizedBox(height: 20),
          // Row with Increase and Decrease buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: _increaseBid,
                child: const Text('Increase Bid by \$50'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
              const SizedBox(width: 20),
              ElevatedButton(
                onPressed: _decreaseBid,
                child: const Text('Decrease Bid by \$50'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  textStyle: const TextStyle(fontSize: 16),
                  backgroundColor: Colors.red, // Different color for decrease
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
